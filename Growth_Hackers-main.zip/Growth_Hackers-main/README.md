# Growth_Hackers

## Test Assignment

Notes: 
1. "Data_Engineer_Work_Sample.pdf" : contains the assignment description
2. BigQuery staging queries for London were executed separately because of different datasource location (EU instead of US). The query results were uploaded to the BigQuery project and later queried as tables to arrive at the final answers. This is true for tasks 1 and 4. 
3. "London_queries.txt" contains the staged queries for the keypoint above.
4. "Models" folder contains all SQL files. 
5. "Models/staged" folder contains staged SQL files which are referened in other models (SQL files) outside "staged" folder.
