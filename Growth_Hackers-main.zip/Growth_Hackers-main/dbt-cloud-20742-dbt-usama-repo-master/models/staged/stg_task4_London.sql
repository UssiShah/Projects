# Task 4: top cities last month
SELECT *
FROM `learning-317207.GH_test.task4_Lond`