# Task 1: Top 20 
SELECT *
FROM `learning-317207.GH_test.Lond_top20`